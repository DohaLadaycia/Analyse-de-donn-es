import numpy as np 
X=np.array([[8,30,55],[2,6,40],[5,15,30],[7,22,40]])
centre_gravite=np.mean(X,axis=0)
print("Centre de graphite est:",centre_gravite)
Y=np.array([X[0,:]-centre_gravite,X[1,:]-centre_gravite,X[2,:]-centre_gravite,X[3,:]-centre_gravite])
print("La matrice centree: \n",Y)
ecart=np.std(X,axis=0)
Z=np.zeros((4,3))
for i in range (4):
    for j in range(3):
        Z[i][j]=Y[i][j]/ecart[j]
print(Z)
V=np.corrcoef(Z)
valeurs_propres, vecteurs_propres = np.linalg.eig(V)
print("Valeurs propres :")
print(np.round(valeurs_propres,3))

