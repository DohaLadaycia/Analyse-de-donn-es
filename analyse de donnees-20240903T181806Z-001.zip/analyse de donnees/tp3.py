import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statistics as stat
import math
M=np.array([[495,776,423,759,1848,655,486],
           [518,995,548,893,2056,584,319],
           [561,1097,887,1167,2630,515,284],
           [414,660,367,638,1620,534,407],
           [400,699,484,762,1856,460,416],
           [324,563,341,544,1507,406,407],
           [319,608,396,568,1501,386,363],
           [243,843,689,1148,2345,438,341],
           [247,428,354,526,1437,332,427],
           [239,559,388,567,1527,293,258],
           [235,767,562,927,1948,372,433]])
#1) Afficher la matrice des corrélations.
centre_gravite=np.mean(M,axis=0)
print("centre_gravite:\n",centre_gravite)
Y=M-centre_gravite
ecart=np.std(M,axis=0,ddof=1)
Z=(M-centre_gravite)/ecart
print("La matrice centrée réduite:\n",Z)
V=np.corrcoef(Z)
print("la matrice des corrélations R des données de la matrice X:\n",np.round(V,3))