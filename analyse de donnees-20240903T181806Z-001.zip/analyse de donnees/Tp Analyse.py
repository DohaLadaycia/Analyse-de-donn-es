import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statistics as stat
import math
X= np.array([[14, 13, 1.50, 45],
              [16, 13, 1.60, 50],
              [15, 13, 1.65, 50],
              [9, 15, 1.75, 60],
              [10, 14, 1.70, 60],
              [7, 14, 1.70, 60],
              [8, 14, 1.60, 70],
              [13, 13, 1.60, 65],
              [17, 15, 1.55, 60],
              [11, 14, 1.70, 65]])
#centre de gravite:
centre_gravite=np.mean(X,axis=0)
print("centre_gravite:\n",centre_gravite)
Y=X-centre_gravite
#Y=np.array([X[0,:]-centre_gravite,X[1,:]-centre_gravite,X[2,:]-centre_gravite,X[3,:]-centre_gravite,X[4,:]-centre_gravite,X[5,:]-centre_gravite,X[6,:]-centre_gravite,X[7,:]-centre_gravite,X[8,:]-centre_gravite,X[9,:]-centre_gravite])
print("La matrice centree: \n",Y)
ecart=np.std(X,axis=0)
Z=Y/ecart
print("La matrice centrée réduite:\n",Z)
V=np.corrcoef(Z)
print("la matrice des corrélations R des données de la matrice X:\n",np.round(V,3))
valeurs_propres, vecteurs_propres = np.linalg.eig(V)
print("Valeurs propres :")
print(np.round(valeurs_propres,3))

