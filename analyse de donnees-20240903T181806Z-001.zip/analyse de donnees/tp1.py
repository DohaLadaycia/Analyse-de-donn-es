import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statistics as stat
import math
X= np.array([[14, 13, 1.50, 45],
              [16, 13, 1.60, 50],
              [15, 13, 1.65, 50],
              [9, 15, 1.75, 60],
              [10, 14, 1.70, 60],
              [7, 14, 1.70, 60],
              [8, 14, 1.60, 70],
              [13, 13, 1.60, 65],
              [17, 15, 1.55, 60],
              [11, 14, 1.70, 65]])
Xt=np.transpose(X)
print("Notre matrice:",X)
individu=[1,2,3,4,5,6,7,8,9,10]
#colonnes:
moyenne=X[:,0]
print(moyenne)
age=X[:,1]
taille=X[:,2]
poids=X[:,3]
#vecteur4,5,6:
vecteur4=X[3,:]
vecteur5=X[4,:]
vecteur6=X[5,:]
moyennes=np.mean(X,axis=0)
variances=np.var(X,axis=0)
ecart_types=np.std(X,axis=0)
X_J=np.transpose(np.vstack((moyennes,variances,ecart_types)))
np.set_printoptions(precision=3)
print("la matrice\n",X_J)
centre_gravite=np.mean(X,axis=0)
print("centre_gravite:",centre_gravite)
v=np.cov(X,rowvar=False)
np.set_printoptions(precision=3)
print(f"Matrice des covariances : \n{v}")
corr_mt = np.corrcoef(moyenne, taille)[0,1]
corr_ap = np.corrcoef(age, poids)[0,1]
print("Le coefficient de corrélation entre la Moyenne et la Taille est :",corr_mt)
print("Le coefficient de corrélation entre la Moyenne et la Taille est :",corr_ap)
# Calcul des valeurs propres et des vecteurs propres de la matrice V
valeurs_propres, vecteurs_propres = np.linalg.eig(v)
print("Valeurs propres :")
print(valeurs_propres)
print("Vecteurs propres :")
print(vecteurs_propres)
